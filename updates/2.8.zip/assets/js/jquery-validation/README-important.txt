#1053 jquery.validate.js 
Modified code to fix summernote console error